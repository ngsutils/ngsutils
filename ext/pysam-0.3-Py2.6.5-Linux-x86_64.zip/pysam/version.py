# pysam versioning information

__version__ = "0.3"

__samtools_version__ = "0.1.8"

__tabix_version__ = "0.2.1"
